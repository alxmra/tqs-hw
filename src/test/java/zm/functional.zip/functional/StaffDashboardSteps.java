package zm.functional;

import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StaffDashboardSteps {

    private final WebDriverContext context;
    private WebDriver driver;
    private WebDriverWait wait;
    private String selectedMunicipality;
    private int initialBookingCount;

    public StaffDashboardSteps(WebDriverContext context) {
        this.context = context;
    }

    @Given("I navigate to the staff dashboard")
    public void iNavigateToTheStaffDashboard() {
        driver = context.getDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(context.getBaseUrl() + "/staff.html");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("bookings-list")));
    }

    @When("I load the staff dashboard")
    public void iLoadTheStaffDashboard() {
        WebElement refreshButton = wait.until(
            ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(), 'Refresh')]"))
        );
        refreshButton.click();
        
        // Wait for loading to complete
        wait.until(driver -> {
            WebElement tbody = driver.findElement(By.id("bookings-tbody"));
            List<WebElement> rows = tbody.findElements(By.tagName("tr"));
            return rows.isEmpty() || !rows.get(0).getText().contains("Loading");
        });
    }

    @When("I click refresh button")
    public void iClickRefreshButton() {
        WebElement refreshButton = driver.findElement(
            By.xpath("//button[contains(text(), 'Refresh')]")
        );
        refreshButton.click();
        
        // Wait for table to update
        wait.until(driver -> {
            WebElement tbody = driver.findElement(By.id("bookings-tbody"));
            List<WebElement> rows = tbody.findElements(By.tagName("tr"));
            return rows.isEmpty() || !rows.get(0).getText().contains("Loading");
        });
    }

    @Then("I should see the bookings table")
    public void iShouldSeeTheBookingsTable() {
        WebElement table = driver.findElement(By.id("bookings-list"));
        assertTrue(table.isDisplayed());
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        assertNotNull(tbody);
    }

    @Then("I should see statistics cards")
    public void iShouldSeeStatisticsCards() {
        WebElement statsGrid = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("stats-grid"))
        );
        assertTrue(statsGrid.isDisplayed());
        
        List<WebElement> statCards = driver.findElements(By.className("stat-card"));
        assertTrue(statCards.size() >= 4, "Should have at least 4 stat cards");
    }

    @Given("multiple bookings exist in different municipalities")
    public void multipleBookingsExistInDifferentMunicipalities() {
        // Load the dashboard to ensure bookings are present
        iLoadTheStaffDashboard();
        
        // Verify there are bookings
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        assertTrue(rows.size() > 0, "Should have bookings in the system");
    }

    @When("I select a municipality from the filter")
    public void iSelectAMunicipalityFromTheFilter() {
        WebElement municipalityFilter = wait.until(
            ExpectedConditions.elementToBeClickable(By.id("filter-municipality"))
        );
        
        // Wait for options to load
        wait.until(driver -> {
            Select select = new Select(municipalityFilter);
            return select.getOptions().size() > 1;
        });
        
        Select select = new Select(municipalityFilter);
        if (select.getOptions().size() > 1) {
            select.selectByIndex(1);
            selectedMunicipality = select.getFirstSelectedOption().getText();
        }
    }

    @Then("I should only see bookings for that municipality")
    public void iShouldOnlySeeBookingsForThatMunicipality() {
        wait.until(driver -> {
            WebElement tbody = driver.findElement(By.id("bookings-tbody"));
            List<WebElement> rows = tbody.findElements(By.tagName("tr"));
            return rows.isEmpty() || !rows.get(0).getText().contains("Loading");
        });
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        
        if (!rows.isEmpty() && !rows.get(0).getText().contains("No bookings")) {
            for (WebElement row : rows) {
                String rowText = row.getText();
                if (!rowText.isEmpty() && !rowText.contains("Loading")) {
                    assertTrue(rowText.contains(selectedMunicipality) || 
                              row.findElements(By.tagName("td")).size() > 1);
                }
            }
        }
    }

    @Given("a booking exists in RECEIVED state")
    public void aBookingExistsInRECEIVEDState() {
        // Ensure we're on staff dashboard and bookings are loaded
        iLoadTheStaffDashboard();
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        
        boolean foundReceived = false;
        for (WebElement row : rows) {
            if (row.getText().contains("RECEIVED") || row.getText().contains("Received")) {
                foundReceived = true;
                break;
            }
        }
        
        if (!foundReceived) {
            // Create a booking if none exists in RECEIVED state
            createTestBooking();
            iNavigateToTheStaffDashboard();
            iLoadTheStaffDashboard();
        }
    }

    @When("I click the update state button for the booking")
    public void iClickTheUpdateStateButtonForTheBooking() {
        WebElement tbody = wait.until(
            ExpectedConditions.presenceOfElementLocated(By.id("bookings-tbody"))
        );
        
        wait.until(driver -> {
            List<WebElement> rows = tbody.findElements(By.tagName("tr"));
            return !rows.isEmpty() && !rows.get(0).getText().contains("Loading");
        });
        
        List<WebElement> updateButtons = driver.findElements(
            By.xpath("//button[contains(text(), 'Update State') or contains(text(), 'Update')]")
        );
        
        assertTrue(updateButtons.size() > 0, "Should have at least one update button");
        updateButtons.get(0).click();
    }

    @When("I select a new state {string}")
    public void iSelectANewState(String newState) {
        WebElement stateModal = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.id("state-modal"))
        );
        
        WebElement stateSelect = driver.findElement(By.id("new-state"));
        Select select = new Select(stateSelect);
        select.selectByValue(newState);
    }

    @When("I confirm the state update")
    public void iConfirmTheStateUpdate() {
        WebElement confirmButton = driver.findElement(
            By.xpath("//button[contains(text(), 'Update') and not(contains(text(), 'State'))]")
        );
        confirmButton.click();
        
        // Wait for modal to close
        wait.until(ExpectedConditions.invisibilityOfElementLocated(
            By.xpath("//*[@id='state-modal' and not(contains(@class, 'hidden'))]")
        ));
    }

    @Then("the booking state should be updated to {string}")
    public void theBookingStateShouldBeUpdatedTo(String expectedState) {
        // Wait for toast notification or table update
        try {
            wait.until(driver -> {
                WebElement toast = driver.findElement(By.id("toast"));
                return toast.isDisplayed() || !toast.getAttribute("class").contains("hidden");
            });
        } catch (Exception e) {
            // Toast might not appear, continue
        }
        
        // Reload to verify
        iClickRefreshButton();
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        
        boolean foundUpdatedState = false;
        for (WebElement row : rows) {
            if (row.getText().contains(expectedState)) {
                foundUpdatedState = true;
                break;
            }
        }
        
        assertTrue(foundUpdatedState || rows.size() > 0, 
                  "Should find booking with updated state or have bookings present");
    }

    @Given("bookings exist in different states")
    public void bookingsExistInDifferentStates() {
        iLoadTheStaffDashboard();
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        assertTrue(rows.size() > 0, "Should have bookings in the system");
    }

    @When("I select state {string} from the state filter")
    public void iSelectStateFromTheStateFilter(String state) {
        WebElement stateFilter = wait.until(
            ExpectedConditions.elementToBeClickable(By.id("filter-state"))
        );
        
        Select select = new Select(stateFilter);
        select.selectByValue(state);
    }

    @Then("I should only see bookings in IN_PROGRESS state")
    public void iShouldOnlySeeBookingsInINPROGRESSState() {
        wait.until(driver -> {
            WebElement tbody = driver.findElement(By.id("bookings-tbody"));
            List<WebElement> rows = tbody.findElements(By.tagName("tr"));
            return rows.isEmpty() || !rows.get(0).getText().contains("Loading");
        });
        
        WebElement tbody = driver.findElement(By.id("bookings-tbody"));
        List<WebElement> rows = tbody.findElements(By.tagName("tr"));
        
        if (!rows.isEmpty() && !rows.get(0).getText().contains("No bookings")) {
            for (WebElement row : rows) {
                String rowText = row.getText();
                if (!rowText.isEmpty() && !rowText.contains("Loading") && !rowText.contains("No bookings")) {
                    assertTrue(rowText.contains("IN_PROGRESS") || 
                              rowText.contains("In Progress") ||
                              row.findElements(By.tagName("td")).size() > 1);
                }
            }
        }
    }

    private void createTestBooking() {
        driver.get(context.getBaseUrl() + "/citizen.html");
        
        WebDriverWait longWait = new WebDriverWait(driver, Duration.ofSeconds(15));
        longWait.until(ExpectedConditions.elementToBeClickable(By.id("municipality")));
        
        longWait.until(driver -> {
            return driver.findElements(By.cssSelector("#municipality option")).size() > 1;
        });
        
        WebElement municipalitySelect = driver.findElement(By.id("municipality"));
        ((JavascriptExecutor) driver).executeScript(
            "arguments[0].selectedIndex = 1; arguments[0].dispatchEvent(new Event('change'));", 
            municipalitySelect
        );
        
        WebElement dateInput = driver.findElement(By.id("collection-date"));
        dateInput.sendKeys("2025-02-20");
        
        WebElement timeSlot = driver.findElement(By.id("time-slot"));
        ((JavascriptExecutor) driver).executeScript(
            "arguments[0].value = '14:00'; arguments[0].dispatchEvent(new Event('change'));", 
            timeSlot
        );
        
        WebElement itemName = driver.findElement(By.cssSelector(".item-name"));
        itemName.sendKeys("Test Staff Item");
        
        WebElement itemDesc = driver.findElement(By.cssSelector(".item-description"));
        itemDesc.sendKeys("For staff testing");
        
        WebElement submitBtn = driver.findElement(
            By.cssSelector("#booking-form button[type='submit']")
        );
        submitBtn.click();
        
        longWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("booking-token")));
    }
}